package com.itecheasy.core.amazon;

/**
 * @author wanghw
 * @date 2015-7-15
 * @description TODO
 * @version
 */
public class AmazonConfigInfo {
	// amazon.feedType=_POST_FLAT_FILE_LISTINGS_DATA_
	// amazon.accessKeyId=AKIAIQTRLDH3SQFB3HSA
	// amazon.secretAccessKey=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
	// amazon.appName=osms
	// amazon.appVersion=1
	// amazon.SellerID=AJ11J3FSAZ6XV
	// amazon.serviceURL=https://mws.amazonservices.com
	// amazon.APISellerUserToken=
	// amazon.MarketplaceID=ATVPDKIKX0DER

	private int tag;
	private String accessKeyId;
	private String secretAccessKey;
	private String SellerID;
	private String serviceURL;
	private String APISellerUserToken;
	private String MarketplaceID;
	private String MarketplaceIDSimple;

	public int getTag() {
		return tag;
	}

	public void setTag(int tag) {
		this.tag = tag;
	}

	public String getAccessKeyId() {
		return accessKeyId;
	}

	public void setAccessKeyId(String accessKeyId) {
		this.accessKeyId = accessKeyId;
	}

	public String getSecretAccessKey() {
		return secretAccessKey;
	}

	public void setSecretAccessKey(String secretAccessKey) {
		this.secretAccessKey = secretAccessKey;
	}

	public String getSellerID() {
		return SellerID;
	}

	public void setSellerID(String sellerID) {
		SellerID = sellerID;
	}

	public String getServiceURL() {
		return serviceURL;
	}

	public void setServiceURL(String serviceURL) {
		this.serviceURL = serviceURL;
	}

	public String getAPISellerUserToken() {
		return APISellerUserToken;
	}

	public void setAPISellerUserToken(String aPISellerUserToken) {
		APISellerUserToken = aPISellerUserToken;
	}

	public String getMarketplaceID() {
		return MarketplaceID;
	}

	public void setMarketplaceID(String marketplaceID) {
		MarketplaceID = marketplaceID;
	}

	public String getMarketplaceIDSimple() {
		return MarketplaceIDSimple;
	}

	public void setMarketplaceIDSimple(String marketplaceIDSimple) {
		MarketplaceIDSimple = marketplaceIDSimple;
	}

}
