package com.itecheasy.core.amazon.isRealIvokeAmazon.resolveAmazonReport;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @Auther: liteng
 * @Date: 2018/8/10 11:34
 * @Description:
 */
public class AmazonStockItemReportFileToVoJsonImpl implements ResolutionReportFile{


    @Override
    public String FileToJson(List<String> filePath, Integer shopId, Map<String, Integer> indexMap) throws IOException {
        return null;
    }

    @Override
    public Map<String, Integer> getReportIndex(String filePath) throws IOException {
        return null;
    }
}
