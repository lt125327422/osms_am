package com.itecheasy.core.amazon;

import java.util.Date;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;


/**
 * @author wanghw
 * @date 2015-5-11
 * @description TODO
 * @version
 */
public class ListOrdersResultAmazon {
	private List<OrderAmazon> orders;
	private Date createdBefore;
	private Date lastUpdatedBefore;

	public List<OrderAmazon> getOrders() {
		return orders;
	}

	public void setOrders(List<OrderAmazon> orders) {
		this.orders = orders;
	}

	public Date getCreatedBefore() {
		return createdBefore;
	}

	public void setCreatedBefore(Date createdBefore) {
		this.createdBefore = createdBefore;
	}

	public Date getLastUpdatedBefore() {
		return lastUpdatedBefore;
	}

	public void setLastUpdatedBefore(Date lastUpdatedBefore) {
		this.lastUpdatedBefore = lastUpdatedBefore;
	}

}
