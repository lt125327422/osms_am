package com.itecheasy.core.amazon;

import java.util.List;

/**
 * @author wanghw
 * @date 2016-12-12
 * @description TODO
 * @version 1.2.2
 */
public class listInventorysResult {
	private String marketplaceId;

	private String nextToken;

	private String sellerId;

	private List<FbaInventory> fbaInventorys;

	public String getMarketplaceId() {
		return marketplaceId;
	}

	public void setMarketplaceId(String marketplaceId) {
		this.marketplaceId = marketplaceId;
	}

	public String getNextToken() {
		return nextToken;
	}

	public void setNextToken(String nextToken) {
		this.nextToken = nextToken;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public List<FbaInventory> getFbaInventorys() {
		return fbaInventorys;
	}

	public void setFbaInventorys(List<FbaInventory> fbaInventorys) {
		this.fbaInventorys = fbaInventorys;
	}

}
