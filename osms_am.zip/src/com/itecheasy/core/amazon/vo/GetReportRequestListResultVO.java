package com.itecheasy.core.amazon.vo;

import java.util.List;

/**
 * @Auther: liteng
 * @Date: 2018/7/2 09:19
 * @Description:
 */
public class GetReportRequestListResultVO {


    private String nextToken;

    private boolean hasNext;

    private List<String> reportRequestIdList;

    private List<String> generatedReportIdList;


    public String getNextToken() {
        return nextToken;
    }

    public void setNextToken(String nextToken) {
        this.nextToken = nextToken;
    }

    public boolean isHasNext() {
        return hasNext;
    }

    public void setHasNext(boolean hasNext) {
        this.hasNext = hasNext;
    }


    public List<String> getReportRequestIdList() {
        return reportRequestIdList;
    }

    public void setReportRequestIdList(List<String> reportRequestIdList) {
        this.reportRequestIdList = reportRequestIdList;
    }

    public List<String> getGeneratedReportIdList() {
        return generatedReportIdList;
    }

    public void setGeneratedReportIdList(List<String> generatedReportIdList) {
        this.generatedReportIdList = generatedReportIdList;
    }
}
