package com.itecheasy.core.amazon.vo;


import java.util.List;


/**
 * @author  liteng
 * @date
 * @describe 接收osms传入的参数
 */
public class TransportContentVO extends BaseVO{

    //shipmentId在父类中
    private Boolean IsPartnered;    //false

    private String ShipmentType;    //SP – 小包裹快递   LTL – 零担货运/货车荷载 (LTL/FTL)    我们是:SP

    private List<TransportDetailInputVO> transportDetailInputVO;

    private String CarrierName;




    public String getCarrierName() {
        return CarrierName;
    }

    public void setCarrierName(String carrierName) {
        CarrierName = carrierName;
    }

    public List<TransportDetailInputVO> getTransportDetailInputVO() {
        return transportDetailInputVO;
    }

    public void setTransportDetailInputVO(List<TransportDetailInputVO> transportDetailInputVO) {
        this.transportDetailInputVO = transportDetailInputVO;
    }

    public Boolean getPartnered() {
        return IsPartnered;
    }

    public void setPartnered(Boolean partnered) {
        IsPartnered = partnered;
    }

    public String getShipmentType() {
        return ShipmentType;
    }

    public void setShipmentType(String shipmentType) {
        ShipmentType = shipmentType;
    }




}
