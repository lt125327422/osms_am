package com.itecheasy.core.amazon.vo;

/**
 * @author  liteng
 * @date
 * @describe transportContent里的一个对象
 */
public class TransportDetailInputVO {



   private String TrackingId;


    public String getTrackingId() {
        return TrackingId;
    }

    public void setTrackingId(String trackingId) {
        TrackingId = trackingId;
    }
}
