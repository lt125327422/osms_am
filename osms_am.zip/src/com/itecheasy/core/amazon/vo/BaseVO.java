package com.itecheasy.core.amazon.vo;

/**
 * @author  liteng
 * @date
 * @describe
 */
public class BaseVO {

    private String shipmentId;

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }
}
