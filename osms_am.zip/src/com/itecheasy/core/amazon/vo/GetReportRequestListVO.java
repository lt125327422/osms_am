package com.itecheasy.core.amazon.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: liteng
 * @Date: 2018/7/2 09:13
 * @Description:
 */
public class GetReportRequestListVO {

    List<String> ids = new ArrayList<String>();

    public List<String> getIds() {
        return ids;
    }

    public void setIds(List<String> ids) {
        this.ids = ids;
    }
}
