package com.itecheasy.core.amazon.vo;

/**
 * 
 * @author taozihao
 * @date2018-6-6 @description 补货商品项
 *
 */
public class InboundItemVO {

	private String sellerSKU;
	private int quantity;


	public String getSellerSKU() {
		return sellerSKU;
	}

	public void setSellerSKU(String sellerSKU) {
		this.sellerSKU = sellerSKU;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
