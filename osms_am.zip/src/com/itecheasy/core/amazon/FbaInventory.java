package com.itecheasy.core.amazon;

import java.util.Date;

/**
 * @author wanghw
 * @date 2016-12-12
 * @description TODO
 * @version 1.2.2
 */
public class FbaInventory {
	private String sellerSKU;

	private String fnsku;

	private String asin;

	private String condition;

	private Integer totalSupplyQuantity;

	private Integer inStockSupplyQuantity;


	private String earliestAvailabilityTimepointType;

	private Date earliestAvailabilityDate;

	public String getEarliestAvailabilityTimepointType() {
		return earliestAvailabilityTimepointType;
	}

	public void setEarliestAvailabilityTimepointType(String earliestAvailabilityTimepointType) {
		this.earliestAvailabilityTimepointType = earliestAvailabilityTimepointType;
	}

	public Date getEarliestAvailabilityDate() {
		return earliestAvailabilityDate;
	}

	public void setEarliestAvailabilityDate(Date earliestAvailabilityDate) {
		this.earliestAvailabilityDate = earliestAvailabilityDate;
	}

	public String getSellerSKU() {
		return sellerSKU;
	}

	public void setSellerSKU(String sellerSKU) {
		this.sellerSKU = sellerSKU;
	}

	public String getFnsku() {
		return fnsku;
	}

	public void setFnsku(String fnsku) {
		this.fnsku = fnsku;
	}

	public String getAsin() {
		return asin;
	}

	public void setAsin(String asin) {
		this.asin = asin;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public Integer getTotalSupplyQuantity() {
		return totalSupplyQuantity;
	}

	public void setTotalSupplyQuantity(Integer totalSupplyQuantity) {
		this.totalSupplyQuantity = totalSupplyQuantity;
	}

	public Integer getInStockSupplyQuantity() {
		return inStockSupplyQuantity;
	}

	public void setInStockSupplyQuantity(Integer inStockSupplyQuantity) {
		this.inStockSupplyQuantity = inStockSupplyQuantity;
	}

}
