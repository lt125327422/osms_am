package com.itecheasy.common.util;

public class ConstantUtils {
	
	//网店title
	public static final int SMT_TITLE_TYPE=1;
	public static final int EBAY_TITLE_TYPE=2;
	public static final int AMAZON_TITLE_TYPE=3;
}
