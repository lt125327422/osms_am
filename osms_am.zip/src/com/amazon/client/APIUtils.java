package com.amazon.client;

import com.itecheasy.core.amazon.AmazonConfigInfo;

/**
 * @author wanghw
 * @date 2015-9-24
 * @description TODO
 * @version
 */
public class APIUtils {
	
	

//		AKIAJCCQJLGRHI5EMRCA	UvLpvIfCXba+m+n+v5l+XqKLpSC7G/6HGcMrjH7G	A25TWSZ8U3NSOK		amazon法国账号	A13V1IB3VIYZZH	法国账号	https://mws.amazonservices.fr
//		AKIAIQTRLDH3SQFB3HSA	k7ubQfyD5LSCA80miOj7TxeM5YAnMkU7GNWlz+tZ	AJ11J3FSAZ6XV		amazon加拿大账号	A2EUQ1WTGCTBG2	加拿大账号	https://mws.amazonservices.ca
//		AKIAJCCQJLGRHI5EMRCA	UvLpvIfCXba+m+n+v5l+XqKLpSC7G/6HGcMrjH7G	A25TWSZ8U3NSOK		amazon西班牙账号	A1RKKUPIHCS9HS	西班牙账号	https://mws.amazonservices.es
//		AKIAJCCQJLGRHI5EMRCA	UvLpvIfCXba+m+n+v5l+XqKLpSC7G/6HGcMrjH7G	A25TWSZ8U3NSOK		amazon意大利账号	APJ6JRA9NG5V4	意大利账号	https://mws.amazonservices.it
//		AKIAJCCQJLGRHI5EMRCA	UvLpvIfCXba+m+n+v5l+XqKLpSC7G/6HGcMrjH7G	A25TWSZ8U3NSOK		amazon德国账号	A1PA6795UKMFR9	德国账号	https://mws.amazonservices.de
//		AKIAJCCQJLGRHI5EMRCA	UvLpvIfCXba+m+n+v5l+XqKLpSC7G/6HGcMrjH7G	A25TWSZ8U3NSOK		amazon英国账号	A1F83G8C2ARO7P	英国账号	https://mws.amazonservices.co.uk
//		AKIAJQHMJL2MNMTMCZ5Q	OECT+4Oze4cfnVaNvc7NMaG+4uFRveKm8R+98q+5	A5XRLSFPCB0HB		amazon日本账号	A1VC38T7YXB528	日本账号	https://mws.amazonservices.jp
	public static AmazonConfigInfo getFr_2() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJCCQJLGRHI5EMRCA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A25TWSZ8U3NSOK");
		fr.setMarketplaceID("A13V1IB3VIYZZH");
		fr.setServiceURL("https://mws.amazonservices.fr");

		return fr;
	}
	
	public static AmazonConfigInfo getIt() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJCCQJLGRHI5EMRCA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A25TWSZ8U3NSOK");
		fr.setMarketplaceID("APJ6JRA9NG5V4");
		fr.setServiceURL("https://mws.amazonservices.it");

		return fr;
	}
	
	public static AmazonConfigInfo getEs_6() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJCCQJLGRHI5EMRCA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A25TWSZ8U3NSOK");
		fr.setMarketplaceID("A1RKKUPIHCS9HS");
		fr.setServiceURL("https://mws.amazonservices.es");

		return fr;
	}
	
	public static AmazonConfigInfo getDe_8() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJCCQJLGRHI5EMRCA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A25TWSZ8U3NSOK");
		fr.setMarketplaceID("A1PA6795UKMFR9");
		fr.setServiceURL("https://mws.amazonservices.de");

		return fr;
	}
	
	public static AmazonConfigInfo getUK_9() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJCCQJLGRHI5EMRCA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A25TWSZ8U3NSOK");
		fr.setMarketplaceID("A1F83G8C2ARO7P");
		fr.setServiceURL("https://mws.amazonservices.co.uk");

		return fr;
	}
	
//	AKIAIQTRLDH3SQFB3HSA	k7ubQfyD5LSCA80miOj7TxeM5YAnMkU7GNWlz+tZ	AJ11J3FSAZ6XV		amazon美国账号	ATVPDKIKX0DER	美国账号	https://mws.amazonservices.com
	public static AmazonConfigInfo getUS() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAIQTRLDH3SQFB3HSA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("AJ11J3FSAZ6XV");
		fr.setMarketplaceID("ATVPDKIKX0DER");
		fr.setServiceURL("https://mws.amazonservices.com");

		return fr;
	}
	public static AmazonConfigInfo getJp_10() {
		AmazonConfigInfo api=new AmazonConfigInfo();
		api.setAccessKeyId("AKIAIS5RA3YWNBTZM5LA");
		api.setAPISellerUserToken("");
		api.setMarketplaceID("A1VC38T7YXB528");
		api.setSecretAccessKey("oDlhHCQ3mie9fpA78OuXaUfqVU305B3SyI8epOxK");
		api.setSellerID("A20UEDX1NF809G");
		api.setServiceURL("https://mws.amazonservices.jp");
		
		return api;
	}

	
	public static AmazonConfigInfo getUS2_18() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJKCLNAZCKDZBWEVA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A14PQ9XE94MKBD");
		fr.setMarketplaceID("ATVPDKIKX0DER");
		fr.setServiceURL("https://mws.amazonservices.com");

		return fr;
	}
	
	public static AmazonConfigInfo getUS3_17() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJOYJ23JZTP57U7BA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A2YTGY7TOKY8BP");
		fr.setMarketplaceID("ATVPDKIKX0DER");
		fr.setServiceURL("https://mws.amazonservices.com");

		return fr;
	}
	
	public static AmazonConfigInfo getCA2_23() {
		AmazonConfigInfo fr = new AmazonConfigInfo();
		fr.setAccessKeyId("AKIAJKCLNAZCKDZBWEVA");
		fr.setAPISellerUserToken("");
		fr.setSecretAccessKey("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");
		fr.setSellerID("A14PQ9XE94MKBD");
		fr.setMarketplaceID("A2EUQ1WTGCTBG2");
		fr.setServiceURL("https://mws.amazonservices.com");

		return fr;
	}
	
}
