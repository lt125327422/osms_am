package com.amazon.test.testVO;

/**
 * @Auther: liteng
 * @Date: 2018/7/2 11:27
 * @Description:
 */
public class AmazonManagerStockResultVO {



}
