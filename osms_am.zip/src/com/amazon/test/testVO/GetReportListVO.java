package com.amazon.test.testVO;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: liteng
 * @Date: 2018/7/2 09:44
 * @Description:
 */
public class GetReportListVO {

    private String nextToken;

    private List<String> ReportRequestIdList = new ArrayList<String>();

    private boolean Acknowledged;

    public List<String> getReportRequestIdList() {
        return ReportRequestIdList;
    }

    public void setReportRequestIdList(List<String> reportRequestIdList) {
        ReportRequestIdList = reportRequestIdList;
    }

    public String getNextToken() {
        return nextToken;
    }

    public void setNextToken(String nextToken) {
        this.nextToken = nextToken;
    }


    public boolean isAcknowledged() {
        return Acknowledged;
    }

    public void setAcknowledged(boolean acknowledged) {
        Acknowledged = acknowledged;
    }
}

