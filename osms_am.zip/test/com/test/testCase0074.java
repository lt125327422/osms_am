package com.test;

import com.itecheasy.common.util.DeployProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @Auther: liteng
 * @Date: 2018/7/28 08:38
 * @Description:
 */
public class testCase0074 {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");


    }
}
